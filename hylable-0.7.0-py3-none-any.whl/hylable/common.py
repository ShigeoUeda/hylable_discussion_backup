"""
Hylable SDK で共通して使用するクラスや関数を定義するモジュールです。
"""
import boto3
import requests
import jwt
import json
import configparser
import os
import pathlib
from dataclasses import dataclass, field, replace
from .error import AuthenticationError, InternalServerError
from typing import Callable
from urllib.parse import urlparse
import paho.mqtt.client


@dataclass
class BaseDataModel:
    """データクラスの元になる基底クラス
    """
    rawdata: dict = field(default_factory=dict, repr=False)

    def sync_data(self, client) -> None:
        """
        サーバにある最新の情報を取得して内容を更新する関数

        Args:
            client (BaseClient): 通信するためのクライアントオブジェクト

        """
        self.rawdata = self._get_data(client).rawdata
        self.__post_init__()

    def _parse_rawdata(self, keypairs) -> None:
        """
        rawdata から指定されたキーの値を取り出して、データに反映する関数

        Args:
            keypairs (list): (データのキー, rawdataのキー) のリスト
        """

        # 指定された objkey (インスタンスのメンバ名) と servicekey (APIから受け取るメンバ名) のペアを取り出す
        for objkey, servicekey in keypairs:
            # コンストラクタで objkey の値が個別に与えられていない場合だけ、API から受け取った値を入れる
            if not getattr(self, objkey):
                if servicekey in self.rawdata and self.rawdata[servicekey] is not None:
                    setattr(self, objkey, self.rawdata[servicekey])

    def _get_data(self, client):
        raise NotImplementedError("This method must be implemented")

    def copy(self):
        return replace(self)


class Defaults:
    var_config_path = "HYLABLE_CONFIG_PATH"
    var_uri = {
        "organization": "HYLABLE_ORGANIZATION_URI",
        "discussion": "HYLABLE_DISCUSSION_URI",
        "recorder": "HYLABLE_RECORDER_URI",
        "bamiel": "HYLABLE_BAMIEL_URI",
        "remote": "HYLABLE_REMOTOE_URI",
        "remote_ui": "HYLABLE_REMOTOEUI_URI",
        "hs3": "HYLABLE_HS3_URI",
        "adapter": "HYLABLE_ADAPTER_URI",
        "report": "HYLABLE_REPORT_URI",
    }
    var_apikey = "HYLABLE_APIKEY"
    config_path = pathlib.Path(".hylable") / "config"


class BaseClient:
    """
    Hylable のサービスと通信するための基底クラス

    インスタンス作成時に `profile_name` にプロフィール名を指定することで
    設定ファイルのプロフィールを切り替えられる
    """
    def __init__(self, profile_name: str = "default") -> None:
        # Find config file path
        self.config = self.load_config_file(profile_name)
        self.profile_name = profile_name
        self.set_constants()

        self.cognito = boto3.Session().client('cognito-idp', 'ap-northeast-1')
        self.jwt = None
        self.login()
        self.get_orginfo()

    def get_orginfo(self):
        ret = self.wrap_request("get", self.get_uri("organization") + f"/{self.orgid}")
        self.available_reports = ret.get("reportFormat", None)

    def load_config_file(self, profile_name: str) -> configparser.ConfigParser:
        # Determine config path
        if Defaults.var_config_path in os.environ:
            config_path = os.environ[Defaults.var_config_path]
        else:
            config_path = pathlib.Path.home() / Defaults.config_path

        assert pathlib.Path(config_path).exists(), FileNotFoundError(
            f"Hylable SDK config file not found in {config_path}"
        )

        # Load config
        parser = configparser.ConfigParser(interpolation=None)
        parser.read(config_path)
        assert profile_name in parser, \
            KeyError(f"profile_name [{profile_name}] not found in {config_path}")
        return parser[profile_name]

    def set_constants(self) -> None:
        # Setup URIs
        self.uris = {
            "organization": "https://api-organization.hylable.com",
            "discussion": "https://gql-discussion.hylable.com/graphql",
            "recorder": "https://gql-recorder.hylable.com/graphql",
            "bamiel": "https://api-bamiel.hylable.com",
            "remote": "https://api-remote.hylable.com",
            "remote_ui": "https://remote.hylable.com",
            "hs3": "https://gql-hs3.hylable.com/graphql",
            "adapter": "https://gql-adapter.hylable.com/graphql",
            "report": "https://api-report.hylable.com",
        }
        # Rewrite URIs if specified
        for service in self.uris:
            if (config_key := f"uri_{service}") in self.config:
                self.uris[service] = self.config[config_key]
            if Defaults.var_uri[service] in os.environ:
                self.uris[service] = os.environ[Defaults.var_uri[service]]

        # Assign apikey if given.
        self.apikey = self.config.get("apikey", None)
        if Defaults.var_apikey in os.environ:
            self.apikey = os.environ[Defaults.var_apikey]

    def get_uri(self, service_name: str) -> str:
        assert service_name in self.uris, KeyError(f"Service {service_name} not found")
        return self.uris[service_name]

    def login(self) -> None:
        """
        ログインする関数。
        インスタンス作成時に自動的にログインを行うので基本的に呼ぶ必要は無いが、
        長時間に渡るとトークンの期限が切れるので、その場合は定期的に呼び出しが必要。
        """
        if self.jwt is None:
            # Run authenticatioin process at the first time
            res = self.cognito.initiate_auth(
                ClientId=self.config["client_id"],
                AuthFlow="USER_PASSWORD_AUTH",
                AuthParameters={
                    'USERNAME': "%(username)s@%(organization)s" % self.config,
                    "PASSWORD": self.config["password"]
                }
            )

            self.jwt = res["AuthenticationResult"]["IdToken"]
            self.refreshToken = res["AuthenticationResult"]["RefreshToken"]

            jwt_decoded = jwt.decode(self.jwt, options={"verify_signature": False})
            self.orgid = jwt_decoded["custom:organization"]
            if self.apikey is None:
                self.apikey = self.orgid.replace("org_", "")
        else:
            # Refresh jwt using Refresh Token after the second time
            res = self.cognito.initiate_auth(
                ClientId=self.config["client_id"],
                AuthFlow='REFRESH_TOKEN_AUTH',
                AuthParameters={
                    'REFRESH_TOKEN': self.refreshToken
                }
            )
            self.jwt = res["AuthenticationResult"]["IdToken"]

    def wrap_graphql_loop(self, url: str, query: dict, variables: dict, extractor: Callable):
        result = []
        variables_for_loop = {**variables, "nextToken": None}
        while True:
            ret = self.wrap_graphql(url, query, variables_for_loop)
            result.extend(extractor(ret)["items"])
            if (nextToken := extractor(ret)["nextToken"]) is None:
                break
            else:
                variables_for_loop["nextToken"] = nextToken
        return result

    def wrap_graphql(self, url: str, query: dict, variables: dict):
        return self.wrap_request(
            "post", url,
            {"query": query, "variables": variables}
        )

    def wrap_request(self, method: str, url: str, data: dict = None, params: dict = {}, is_rawtext=False):
        headers = {
            "Authorization": f"Bearer {self.jwt}",
        }
        func = getattr(requests, method.lower())
        if data is not None:
            data = json.dumps(data)
        ret = func(url, data=data, headers=headers, params=params)

        # Return if the response is expected to be raw text
        if is_rawtext:
            return ret.text

        if len(text := ret.text) == 0:
            return {}
        retobj = json.loads(text)
        assert retobj is not None, "ERROR: None"

        if "message" in retobj:
            msg = retobj["message"]
            if msg == "Access Denied":
                raise AuthenticationError(retobj["message"])
            elif msg == "Internal server error":
                raise InternalServerError()
            else:
                raise Exception(msg)

        assert "error" not in retobj, f"ERROR: {json.dumps(retobj)}"
        assert "errors" not in retobj, f"ERROR: {json.dumps(retobj)}"
        return retobj

    def wrap_subscribe(
            self,
            url: str,
            queries: list,
            variables: list,
            topic_filters: list,
            callback: Callable):
        self.topic_filters = topic_filters
        self.callback = callback
        self.is_alive = True

        # 指定された　subscription を実行して、MQTTのトピックを取得する
        for query, variable in zip(queries, variables):
            ret = self.wrap_graphql(url, query, variable)
        root = ret["extensions"]["subscription"]["mqttConnections"][0]
        self.topic_connect = root["topics"]
        urlobj = urlparse(root["url"])
        client_id = root["client"]

        # mqtt のトピックを購読する
        mqtt_client = paho.mqtt.client.Client(client_id=client_id, transport="websockets")
        mqtt_client.on_connect = self._subscribe_on_connect
        mqtt_client.on_message = self._subscribe_on_message
        mqtt_client.ws_set_options(path=f'{urlobj.path}?{urlobj.query}', headers={
            'Host': '{0:s}'.format(urlobj.netloc)
        })
        mqtt_client.tls_set()
        mqtt_client.connect(urlobj.netloc, port=443)
        mqtt_client.loop_forever()

    def _subscribe_on_connect(self, client, userdata, flags, response_code):
        for topic in self.topic_connect:
            client.subscribe(topic)

    def _subscribe_on_message(self, client, userdata, msg):
        for topic_filter in self.topic_filters:
            # topic_filter に無いメッセージはすべて無視
            if topic_filter not in msg.topic:
                continue
            ret = json.loads(msg.payload)["data"][topic_filter]
            self.callback(ret)
            if not self.is_alive:
                client.disconnect()
