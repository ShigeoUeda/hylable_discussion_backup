"""
Hylable Web 会議システムを操作するソフトウェアを開発するためのモジュールです。
最初に :class:`WebMeetingClient` クラスのインスタンスを作成して、そのメソッドを実行することで操作を行います。

データは、以下の `dataclass` で定義されるクラスのオブジェクトとして扱います

- ルーム: :class:`Room`
- ゲスト用のURL: :class:`GuestUrl`
"""
import json
import datetime
from dataclasses import dataclass, field
from dateutil.parser import parse as dparse

from .common import BaseClient, BaseDataModel


@dataclass
class Room(BaseDataModel):
    """Web会議ルームを表す `dataclass`

    Attributes:
        id (str): ルームのID
        name (str): ルームの名前
        orgid (str): 組織のID
        course_id (str): ルームに紐付けられているコースのID
        analysis (dict): ルームの分析結果を表す dict

            activity
                キーがメンバーID、値がアクティビティのフレームのリストである dict
                詳細は :attr:`hylable.hd.Discussion.frames` を参照

            turntake
                dict の dict 、最初のキーがターンテイクの発生回数を表す。
                詳細は :attr:`hylable.hd.Discussion.stats` を参照

            tlot_ms
                キーがメンバーID、当該メンバーの発話時間を表す dict
                詳細は :attr:`hylable.hd.Discussion.stats` を参照


        discussion_id (str): 分析中の場合、ルームのディスカッションID
        members (list): ルームに参加しているメンバーのリスト。
            リストの要素は {'position': int, 'members': str, 'is_left': bool} である。
            それぞれの key の意味は以下の通り

            position
                0 から 360 の数値で、メンバーの仮想的な角度を表す。
            member
                :class:`hylable.hd.Member` クラスのオブジェクトにおけるメンバーのIDを表す。
            is_left
                メンバーがルームから退出したかどうかを表す。

        status (str): ルームのステータス

            .. list-table::

                * - closed
                  - ルームが閉じられている
                * - open
                  - ルームが開かれている
                * - inqueue
                  - ルームを開いている途中
 
    """
    id: str = ''
    name: str = ''
    orgid: str = ''
    course_id: str = ''
    analysis: dict = field(default_factory=dict)
    discussion_id: str = ''
    members: list = field(default_factory=list)
    status: str = ''

    def __post_init__(self) -> None:
        self.keypairs = [
            ('id', 'id'),
            ('name', 'name'),
            ('orgid', 'orgid'),
            ('course_id', 'crsid'),
            ('analysis', 'analysis'),
            ('discussion_id', 'discussion_id'),
            ('members', 'members'),
            ('status', 'status'),
        ]
        self._parse_rawdata(self.keypairs)
        self.analysis = json.loads(self.rawdata.get('analysis', '{}'))

        if "tlotMs" in self.analysis.keys():
            self.analysis["tlot_ms"] = self.analysis["tlotMs"]
            del self.analysis["tlotMs"]
        self.members = json.loads(self.rawdata.get('members', []))
        for m in self.members:
            if "isLeft" in m.keys():
                m["is_left"] = m["isLeft"]
                del m["isLeft"]

    def _as_dict(self) -> dict:
        return {
            key2: getattr(self, key1)
            for key1, key2 in self.keypairs
            if hasattr(self, key1)
        }


@dataclass
class GuestUrl(BaseDataModel):
    """ゲスト用のURLを表す `dataclass`

    Attributes:
        createdAt (datetime): URL の作成日時
        start (datetime): URL の有効期限の開始日時
        end (datetime): URL の有効期限の終了日時
        room_id (str): URL のルームID
        metadata (dict): URL のメタデータ
        url (str): URL

    """
    application: str = 'remote'
    createdAt: datetime.datetime = None
    start: datetime.datetime = None
    end: datetime.datetime = None
    token: str = ''
    room_id: str = ''
    metadata: dict = field(default_factory=dict)
    url: str = ''

    def __post_init__(self) -> None:
        self.keypairs = [
            ('token', 'token'),
            ('room_id', 'key'),
            ('token', 'token'),
        ]
        self._parse_rawdata(self.keypairs)

        keys = ["createdAt", "start", "end"]
        for key in keys:
            if self.rawdata.get(key, None) is not None:
                setattr(self, key, dparse(self.rawdata.get(key, None)))

        if "metadata" in self.rawdata and self.rawdata["metadata"] is not None:
            self.metadata = json.loads(self.rawdata["metadata"])

    def set_url(self, client) -> None:
        """URLを設定する関数

        Args:
            url (str): 設定するURL
        """
        self.url = f'{client.get_uri("remote_ui")}/#/guest?r={self.room_id}&t={self.token}'


class WebMeetingClient(BaseClient):
    """
    Hylable Web 会議システム との通信を行うクラス
    """
    def get_rooms(self) -> list[Room]:
        """
        すべての会議ルームのリストを得る関数

        Returns:
            list[Room]: ルームのリスト

        Examples:
            >>> client = WebMeetingClient()
            >>> rooms = client.get_rooms()
        """
        url = f"{self.get_uri('remote')}/{self.orgid}/room"
        return list(map(Room, self.wrap_request("get", url)))

    def get_room(self, room: Room) -> Room:
        """
        会議ルームの詳細を取得する関数

        Args:
            room (Room): 取得する会議ルーム

        Returns:
            Room: 取得した会議ルーム

        Examples:
            >>> client = WebMeetingClient()
            >>> room = [r for r in rooms if r.name == "target"][0]
            >>> room = client.get_room(room)
        """
        if not room.id:
            raise KeyError("room object do not have ID")
        url = f"{self.get_uri('remote')}/{self.orgid}/room/{room.id}"
        return Room(self.wrap_request("get", url))

    def add_room(self, room: Room) -> Room:
        """
        会議ルームを追加する関数

        Args:
            room (Room): 追加する会議ルーム。name と course_id が必要

        Returns:
            Room: 追加した会議ルーム

        Examples:
            >>> client = WebMeetingClient()
            >>> room = Room(name="test")
            >>> client.add_room(room)
        """

        url = f"{self.get_uri('remote')}/{self.orgid}/room"
        if not room.name:
            raise KeyError("room.name cannot be empty")
        if not room.course_id:
            raise KeyError("room.course_id cannot be empty")
        return Room(self.wrap_request(
            "post", url,
            data={k: room._as_dict()[k] for k in ["name", "crsid"]}
        ))

    def del_room(self, room: Room):
        """
        会議ルームを削除する関数

        Args:
            room (Room): 削除する会議ルーム

        Examples:
            >>> client = WebMeetingClient()
            >>> room = Room(name="test")
            >>> client.del_room(room)
        """

        url = f"{self.get_uri('remote')}/{self.orgid}/room/{room.id}"
        self.wrap_request("delete", url)

    def get_guest_urls(self, room_id: str = "") -> list[GuestUrl]:
        """
        ゲスト用のURLのリストを取得する関数

        Args:
            room_id (str): 取得する会議ルームのID

        Returns:
            list[GuestUrl]: ゲスト用のURLのリスト

        Examples:
            >>> client = WebMeetingClient()
            >>> all_urls = client.get_guest_urls()
            >>> room = client.get_rooms()[0]
            >>> url = client.get_guest_urls(room.id)
        """
        ret = self.wrap_request(
            "get", f"{self.uris['remote']}/{self.orgid}/token"
        )["tokens"]

        for url in (urls := list(map(GuestUrl, ret))):
            url.set_url(self)

        if room_id != "":
            urls = [url for url in urls if url.room_id == room_id]
        return urls

    def del_guest_url(self, guesturl: GuestUrl):
        """
        ゲスト用のURLを削除する関数

        Args:
            guesturl (GuestUrl): 削除するゲスト用のURL

        Examples:
            >>> client = WebMeetingClient()
            >>> guesturl = GuestUrl()
            >>> client.del_guest_url(guesturl)
        """
        url = f"{self.get_uri('remote')}/{self.orgid}/room/{guesturl.room_id}/token/{guesturl.token}"
        self.wrap_request("delete", url)

    def add_guest_url(self, room_id: str, topic: str = "",
                      start: datetime.datetime = None,
                      end: datetime.datetime = None) -> GuestUrl:
        """
        ゲスト用のURLを追加する関数

        Args:
            guesturl (GuestUrl): 追加するゲスト用のURL

        Examples:
            >>> client = WebMeetingClient()
            >>> guesturl = GuestUrl()
            >>> client.add_guest_url(guesturl)
        """
        url = f"{self.get_uri('remote')}/{self.orgid}/room/{room_id}/token"
        data = {"metadata": json.dumps({"title": topic})}
        if start is not None:
            data["start"] = start.isoformat()
        if end is not None:
            data["end"] = end.isoformat()

        ret = self.wrap_request("post", url, data=data)
        guest_url = GuestUrl(
            room_id=room_id,
            token=ret['token'],
            start=start,
            end=end,
            metadata={"title": topic}
        )
        guest_url.set_url(self)
        return guest_url
