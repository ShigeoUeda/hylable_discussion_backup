"""
Hylable Discussion を操作するソフトウェアを開発するためのモジュールです。
最初に :class:`HDClient` クラスのインスタンスを作成して、そのメソッドを実行することで操作を行います。

データは、以下の `dataclass` で定義されるクラスのオブジェクトとして扱います

- コース: :class:`Course`
- ディスカッション: :class:`Discussion`
- メンバー: :class:`Member`
- レコーダー: :class:`Recorder`

"""
import datetime
import json
import pathlib
from dataclasses import dataclass, field
from typing import Callable

import numpy
import requests
from typing import Union
from dateutil.parser import parse as dparse

from .common import BaseClient, BaseDataModel
from .queries_hd import (create_discussion, get_discussion, get_discussions, update_discussion,
                         get_mp3, get_recorders, recstart, recstop, reboot, shutdown, speak, del_discussion,
                         subscribe_discussion_onchange, subscribe_discussion_ondelete, subscribe_recorder_update)
from .error import DataNotFoundError
from .hs3 import HS3Client


@dataclass
class Member(BaseDataModel):
    """メンバーを表す `dataclass`

    Attributes:
        id (str):
            `mem_` から始まるメンバーの ID
        orgid (str):
            `org_` から始まる組織の ID
        name (str):
            メンバーの名前
        course_ids (list[str]):
            このメンバーが登録されているコースIDのリスト
        account (dict):
            このメンバーのアカウント情報
    """
    id: str = ''
    orgid: str = ''
    name: str = ''
    course_ids: list = field(default_factory=list)
    account: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        keypairs = [
            ('id', 'ID'),
            ('name', 'name'),
            ('orgid', 'OrgID'),
            ('course_ids', 'course'),
            ('account', 'account')
        ]
        self._parse_rawdata(keypairs)

    def _get_data(self, client):
        return client.get_member(self.id)

    def _as_dict(self) -> dict:
        return {
            'ID': self.id,
            'name': self.name,
            'OrgID': self.orgid,
            'course': self.course_ids,
            'account': self.account,
        }


@dataclass
class Course(BaseDataModel):
    """コースを表す `dataclass`

    Attributes:
        id(str):
            `crs_` から始まるコースの ID
        orgid(str):
            `org_` から始まる組織の ID
        comment(str):
            コースに対するコメント
        name(str):
            コースの名前
        year(int):
            コースの実施年
        members(List[Member]):
            コースに登録されているメンバーのリスト
        group(List[dict]):
            レコーダーの座席情報のリスト
    """
    id: str = ''
    orgid: str = ''
    comment: str = ''
    name: str = ''
    year: int = 0
    members: list[Member] = field(default_factory=list)
    group: list = field(default_factory=list)

    def __post_init__(self) -> None:
        keypairs = [
            ('id', 'ID'),
            ('name', 'name'),
            ('orgid', 'OrgID'),
            ('year', 'year'),
            ('comment', 'comment'),
            ('group', 'group'),
            ('members', 'member'),
        ]
        self._parse_rawdata(keypairs)

        self.members = list(map(Member, self.members))
        self.flags = {"useNewCaDa": True}
        if "flags" in self.rawdata:
            self.flags.update(self.rawdata["flags"])

    def _get_data(self, client):
        return client.get_course(self.id)

    def _as_dict(self):
        return {
            'name': self.name,
            'year': self.year,
            'comment': self.comment,
        }


@dataclass
class Recorder(BaseDataModel):
    """レコーダーを表す `dataclass`

    Attributes:
        id(str):
            レコーダーのID
        name(str):
            レコーダーの名前
        orgid(str):
            `org_` から始まる組織の ID
        type(str):
            レコーダーのタイプ
        assign(str):
            レコーダーが登録された対象のID。
            Hylable Discussion であればコースIDが、 Bamiel であればフィールドIDが入る。
        connected(bool)
            レコーダーがサーバーに接続されているかを表すフラグ
        status(str):
            レコーダーの状態
        version(str):
            レコーダーのファームウェアのバージョン
    """
    id: str = ''
    name: str = ''
    orgid: str = ''
    type: str = ''

    assign: str = ''
    connected: bool = False
    status: str = ''
    version: str = ''

    def __post_init__(self) -> None:
        keypairs = [
            ('id', 'id'),
            ('name', 'name'),
            ('orgid', 'organizationId'),
            ('type', 'type'),
            ('assign', 'assign'),
            ('connected', 'connected'),
            ('status', 'status'),
            ('version', 'version'),
        ]
        self._parse_rawdata(keypairs)

    def _get_data(self, client):
        return client.get_recorder(self.id)


@dataclass
class Discussion(BaseDataModel):
    """ディスカッションを表す `dataclass`

    Attributes:
        id(str):
            UUID で表されるディスカッションの ID
        course_id(str):
            `crs_` から始まるこのディスカッションが所属するコースのID
        orgid(str):
            `org_` から始まる組織の ID
        recordedAt(Date):
            このディスカッションの録音が開始された時刻。タイムゾーンは UTC。
        topic(str):
            このディスカッションのトピック
        comment(str):
            このディスカッションに対するコメント
        duration_sec(int):
            このディスカッションの長さ (単位は秒)
        progress(int):
            このディスカッションの分析の進捗状況 (0から100まで)
        status(str):
            このディスカッションの状態。以下のいずれかの値を取る。

            .. list-table::

                * - created
                  - ディスカッションが作成完了
                * - recording
                  - 録音中
                * - uploading
                  - アップロード中
                * - completed
                  - 分析が完了している
                * - error
                  - エラーが発生した

        recorder(Recorder):
            このディスカッションの収録に使われたレコーダー
        group_name(str):
            このディスカッションを行ったグループ名
        members(list[dict]):
            このディスカッションに参加したメンバーのリスト
            リストの各要素は、ディクショナリになっている。
            各ディクショナリはメンバーの位置をあらわす `position` と、メンバー情報自体を表す `member` のプロパティをもつ。
            {'position': -30, 'member': 該当するメンバーのオブジェクト}
        frames(dict):
            このディスカッションのフレームごとの分析結果。dictionary の key は以下の通り。

            activity (list)
                メンバーごとの発話量の時間変化を表すリストのリスト。リストのサイズはフレーム数 x メンバー数。
                フレームは 5秒ごとに計算される。それぞれの数値は 0 から 1 までの値をとり、
                当該フレーム内における、そのメンバーの発話量の割合を表す。
                値の順番は members の並びと同じ。

        stats(dict):
            このディスカッションの分析結果の統計データ。 dictionary の key は以下の通り。

            activity (list)
                メンバーごとの発話量のリスト。 値の順番は members の並びと同じ。
                最小値0、最大値1で、値が大きいほど発話量が多い。

            enhancement (list)
                メンバーごとの盛り上げ量のリスト。 値の順番は members の並びと同じ。
                最小値0、最大値1で、値が大きいほどそのメンバーの発話後に他のメンバーの発話量が増加したことを表す。
                0.5 のときは変化なし。0.5 以下のときは盛り下がったことを、
                0.5 より大きいときは盛り上がったことを表す。

            overlap (list)
                メンバーごとの重なり量のリスト。 値の順番は members の並びと同じ。
                最小値0、最大値1で、値が大きいほどそのメンバーと他のメンバーの発話の重複が多いことを表す。

            tlot_ms (list)
                メンバーごとの総発話時間のリスト。 値の順番は members の並びと同じ。
                単位はミリ秒。

            duration_per_azimuth (dict)
                方向ごとの音声検出時間。dict には azimuth と duration のプロパティがある。
                azimuth と duration はそれぞれ同じ長さの numpy.array で、それぞれ対応している。
                方位角ごとに、その方向から到来した音声の長さを表す (単位はミリ秒)。

            overlap_matrix (list)
                メンバーごとの重なり量を表すリストのリスト。二次元正方行列で、行列のサイズはメンバー数と同じ。
                行列の (i, j) 要素は、メンバー i からメンバー j へ重なった量を表す。

            turntake_matrix (list)
                メンバーごとのターンテイクを表すリストのリスト。二次元正方行列で、行列のサイズはメンバー数と同じ。
                行列の (i, j) 要素は、メンバー i の後にメンバー j が発言した回数表す。

        annotations(list[dict]):
            このディスカッションに対するアノテーション。
            形式は以下の通りで。開始と終了時刻はミリ秒。
            {'begin': 開始時刻, 'end': 終了時刻, 'label': アノテーションの内容}
    """
    id: str = ''
    course_id: str = ''
    orgid: str = ''
    recordedAt: datetime.datetime = None

    topic: str = ''
    comment: str = ''
    duration_sec: int = 0
    progress: int = 0
    status: str = ''

    recorder: Recorder = None
    group_name: str = ''
    members: list[dict[str, Union[int, float, Member]]] = field(default_factory=list)

    frames: dict = field(default_factory=dict)
    stats: dict = field(default_factory=dict)

    annotations: list = field(default_factory=list)

    dest: str = field(default_factory=str, repr=False)

    # 内部用
    _group: str = field(default_factory=dict, repr=False)
    options: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        keypairs = [
            ('id', 'id'),
            ('course_id', 'cid'),
            ('orgid', 'oid'),
            ('topic', 'topic'),
            ('comment', 'comment'),
            ('status', 'status'),
            ('dest', 'dest'),
            ('recordedAt', 'recordedAt'),
            ('duration_sec', 'duration'),
            ('progress', 'progress'),
            ('recorder', 'recorder'),
            ('annotations', 'annotations'),
            ('_group', 'group'),
        ]
        self._parse_rawdata(keypairs)

        if self.recordedAt is not None:
            self.recordedAt = dparse(self.recordedAt)
        if self.recorder is not None:
            self.recorder = Recorder(
                {** self.rawdata['recorder'], 'orgid': self.orgid}
            )
        self.duration_sec = int(self.duration_sec)
        self.progress = int(self.progress)

        # parse group
        self.group_name = self._group.get('name', '')
        self.members = [
            {
                'position': m['position'],
                'member': Member(id=m['memberId'], orgid=self.orgid)
            }
            for m in self._group.get('seats', [])
        ]

        # parse frames
        self.frames = {}
        if (f := self.rawdata.get('framewiseAnalysis', None)) is not None:
            if 'activity' in f:
                self.frames['activity'] = numpy.array(f['activity'])
            else:
                self.frames['activity'] = None

        # parse stats
        self.stats = {}
        if (s := self.rawdata.get('statistics', None)) is not None:
            self.stats['activity'] = numpy.array(s['activity'])
            self.stats['enhancement'] = numpy.array(s['enhancement'])
            self.stats['overlap'] = numpy.array(s['overlap'])
            self.stats['tlot_ms'] = numpy.array(s['tlotMs'])
            self.stats['dominant_ms'] = numpy.array(s['dominantMs'])
            self.stats['duration_per_azimuth'] = {
                "azimuth": numpy.array([
                    d['azimuth'] for d in s['durationPerAzimuth'] if d is not None
                ]),
                "duration": numpy.array([
                    d['duration'] for d in s['durationPerAzimuth'] if d is not None
                ]),
            }
            self.stats['overlap_matrix'] = numpy.nan_to_num(numpy.array(
                s['pairwiseOverlap'], dtype=numpy.float16
            ), nan=0)

            self.stats['turntake_matrix'] = numpy.nan_to_num(numpy.array(
                s['turntake'], dtype=numpy.float16
            ), nan=0)

        # parse options
        self.options = {}
        if "options" in self.rawdata:
            self.options.update(self.rawdata["options"])

    def _get_data(self, client):
        return client.get_discussion(self.id)

    def _as_dict(self):
        return {
            'id': self.id,
            'cid': self.course_id,
            'topic': self.topic,
            'comment': self.comment,
            'group': {
                'name': self.group_name,
                'seats': [
                    {'position': m['position'], 'memberId': m['member'].id}
                    for m in self.members
                ]
            },
            'annotations': self.annotations,
        }


class HDClient(BaseClient):
    """
    Hylable Discussion との通信を行うクラス
    """
    def get_courses(self) -> list[Course]:
        """
        すべてのコースを得る関数

        Returns:
            list[Course]: コースのリスト

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/course"
        return list(map(Course, self.wrap_request("get", url)))

    def get_course(self, course_id: str) -> Course:
        """
        特定のコースの詳細を得る関数

        Args:
            course_id(str): コースのID

        Returns:
            Course: ID に対応するコースのオブジェクト

        Raises:
            DataNotFoundError: 指定されたコースIDがない時

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> course = client.get_course(courses[0].id)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/course/{course_id}"
        if (obj := self.wrap_request("get", url)):
            return Course(obj)
        else:
            raise DataNotFoundError(f"Course ID {course_id} not found")

    def add_course(self, course: Course) -> None:
        """
        コースを追加する関数

        Args:
            course(Course): 追加するコース

        Examples:
            >>> client = HDClient()
            >>> course = Course({
            >>>     "name": "test course",
            >>>     "year": 2021,
            >>>     "comment": "test course"
            >>> })
            >>> client.add_course(course)
            >>> # 追加したコースを取得
            >>> course = [
                    c for c in client.get_courses()
                    if c.name == "test course"
                ][0]
        """

        # Create a course
        url = f"{self.get_uri('organization')}/{self.orgid}/course"
        self.wrap_request("post", url, data=course._as_dict())

    def del_course(self, course: Course) -> None:
        """
        コースを削除する関数

        Args:
            course(Course): 削除するコースのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> client.del_course(course.id)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/course/{course.id}"
        self.wrap_request("delete", url)

    def update_course(self, course: Course) -> None:
        """
        コースを更新する関数

        Args:
            course(Course): 更新するコースのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> course = client.get_course(course_id)
            >>> course.name = "new name"
            >>> client.update_course(course)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/course/{course.id}"
        self.wrap_request("put", url, data=course._as_dict())

    def get_members(self) -> list[Member]:
        """
        すべてのメンバーリストを得る関数

        Returns:
            list[Member]: メンバーのリスト

        Examples:
            >>> client = HDClient()
            >>> members = client.get_members()
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/member"
        return list(map(Member, self.wrap_request("get", url)))

    def get_member(self, member_id: str) -> Member:
        """
        特定のメンバーの詳細を得る関数

        Args:
            member_id(str): メンバーのID

        Returns:
            Member: member_id に対応するメンバーのオブジェクト

        Raises:
            DataNotFoundError: 指定されたメンバーIDがない時

        Examples:
            >>> client = HDClient()
            >>> members = client.get_members()
            >>> member = client.get_member(members[0].id)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/member/{member_id}"
        if (obj := self.wrap_request("get", url)):
            return Member(obj)
        else:
            raise DataNotFoundError(f"Member ID {member_id} not found")

    def add_members(self, members: list[Member]) -> list[Member]:
        """
        組織にメンバーを追加する関数

        Returns:
            list[Members]: メンバーのリスト

        Examples:
            >>> client = HDClient()
            >>> members_in = [
                    Member(name="メンバー1"),
                    Member(name="メンバー2"),
                    Member(name="メンバー3")
                ]
            >>> members_out = client.add_members(members_in)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/member"
        added_members = self.wrap_request("post", url, data=[
            {"name": m.name} for m in members
        ])
        return list(map(Member, added_members))

    def del_member(self, member: Member) -> None:
        """
        メンバーを削除する関数

        Args:
            member(Member): 削除するメンバーのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> member = [
                    m for m in client.get_members()
                    if m.name == "MEMBER_TO_DELETE"
                ][0]
            >>> client.del_member(member.id)
        """
        url = f"{self.get_uri('organization')}/{self.orgid}/member/{member.id}"
        self.wrap_request("delete", url)

    def update_member(self, member: Member, password: str = "") -> None:
        """
        メンバーを更新する関数

        Args:
            member(Member): 更新するメンバーのオブジェクト
            password(str): メンバーのアカウントのパスワード。新規作成するときのみ必要。

        Examples:
            >>> client = HDClient()
            >>> member = client.get_member(member_id)
            >>> print("メンバー名を変更する")
            >>> member.name = "new name"
            >>> client.update_member(member)
            >>>
            >>> print("メンバーのアカウントを作成する")
            >>> member.account = {
                    "name": "my login name",
                    "type": "viewer",  # アカウントの権限
                }
            >>> client.update_member(member, password="my password")
        """

        baseurl = f"{self.get_uri('organization')}/{self.orgid}/member/{member.id}"

        # update member name
        url = f"{baseurl}"
        self.wrap_request("put", url, data={"name": member.name})

        # update member account
        url = f"{baseurl}/account"
        if member.account:
            if password:
                # Member に account があり、パスワードもあるときは新規作成なので POST
                self.wrap_request("post", url, data={
                    "loginName": member.account['name'],
                    "password": password,
                    "type": member.account['type'],
                })
            else:
                # Member に account があり、パスワードが無いときは更新なので PUT
                self.wrap_request("put", url, data={
                    "loginName": member.account['name'],
                    "type": member.account['type'],
                })
        else:
            # name を put した時点で account は消えているので、ここではなにもしない。
            pass

    def get_discussions(self, course_id: str) -> list[Discussion]:
        """
        指定されたコースにある全てのディスカッションを得る関数

        Returns:
            list[Discussion]: ディスカッションのリスト

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> discussions = client.get_discussions(courses[0].id)
        """
        result = self.wrap_graphql_loop(
            url=self.get_uri("discussion"),
            query=get_discussions,
            variables={"cid": course_id},
            extractor=lambda r: r["data"]["listDiscussions"]
        )
        return list(map(Discussion, result))

    def get_discussion(self, discussion_id: str) -> Discussion:
        """
        特定のディスカッションの詳細を得る関数

        Args:
            discussion_id(str): ディスカッションのID

        Returns:
            Discussion: discussion_id に対応するディスカッションのオブジェクト

        Raises:
            DataNotFoundError: 指定されたディスカッションIDがない時

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> discussions = client.get_discussions(courses[0].id)
            >>> discussion = client.get_discussion(discussions[0].id)
        """
        ret = self.wrap_graphql(
            url=self.get_uri("discussion"),
            query=get_discussion,
            variables={"did": discussion_id}
        )
        if (obj := ret["data"]["getDiscussion"]):
            return Discussion(obj)
        else:
            raise DataNotFoundError(f"Discussion ID {discussion_id} not found")

    def del_discussion(self, discussion: Discussion) -> None:
        """
        特定のディスカッションを削除する関数

        Args:
            discussion(Discussion): 削除するディスカッションのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> discussion_obj = Discussion("ID OF THE DISCUSSION")
            >>> client.get_discussions(discussion_obj)
        """
        self.wrap_graphql(
            url=self.get_uri("discussion"),
            query=del_discussion,
            variables={"input": discussion.id}
        )

    def update_discussion(self, discussion: Discussion) -> None:
        """
        ディスカッションを更新する関数

        Args:
            discussion(Discussion): 更新するディスカッションのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> discussion = client.get_discussion(discussion_id)
            >>> discussion.title = "new title"
            >>> discussion.members[0]['position'] = 0
            >>> client.update_discussion(discussion)
        """
        self.wrap_graphql(
            url=self.get_uri("discussion"),
            query=update_discussion,
            variables={"input": discussion._as_dict()}
        )

    def get_mp3(self, discussion: Discussion, filelike=None) -> bytes:
        """
        指定されたディスカッションの 音声データを mp3 で詳細を得る関数

        Args:
            discussion(Discussion): 音声データを得るディスカッションのオブジェクト
            filelike(str or None): ファイルを保存するパス。デフォルトでは保存しない

        Returns:
            bytes: mp3 を表すデータ

        Raises:
            DataNotFoundError: 指定されたディスカッションIDに mp3 がないとき

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> discussions = client.get_discussions(courses[0].id)
            >>> data = client.get_mp3(discussions[0].id, 'audio.mp3')
            >>> pathlib.Path('audio2.mp3').write_bytes(data)
        """
        ret = self.wrap_graphql(
            url=self.get_uri("discussion"),
            query=get_mp3,
            variables={"id": discussion.id, "apikey": self.apikey}
        )
        if (obj := ret["data"]["getAudioUrl"]["result"]) is None:
            raise DataNotFoundError(f"MP3 of {discussion.id} not found")

        mp3 = requests.get(json.loads(obj)).content
        if filelike is not None:
            with pathlib.Path(filelike).open("wb") as handle:
                handle.write(mp3)

        return mp3

    def get_recorder(self, recorder_id: str) -> Recorder:
        """
        特定のレコーダーの詳細を得る関数

        Args:
            recorder_id(str): レコーダーのID

        Returns:
            Recorder: recorder_id に対応するレコーダーのオブジェクト

        Raises:
            DataNotFoundError: 指定されたレコーダーIDがない時

        Examples:
            >>> client = HDClient()
            >>> recorder_id = "ID OF THE RECORDER"
            >>> recorder = client.get_recorder(recorder_id)
        """
        ret = self.wrap_graphql_loop(
            url=self.get_uri("recorder"),
            query=get_recorders,
            variables={"filter": {
                "organizationId": {"eq": self.orgid},
                "id": {"eq": recorder_id}
            }},
            extractor=lambda r: r["data"]["listRecorders"],
        )
        if len(ret) > 0:
            return Recorder(ret[0])
        else:
            raise DataNotFoundError(f"Recorder {recorder_id} not found")

    def get_recorders(self) -> list[Recorder]:
        """
        すべてのレコーダーを得る関数

        Returns:
            list[Recorder]: レコーダーのリスト

        Examples:
            >>> client = HDClient()
            >>> members = client.get_recorders()
        """
        result = self.wrap_graphql_loop(
            url=self.get_uri("recorder"),
            query=get_recorders,
            variables={"filter": {"organizationId": {"eq": self.orgid}}},
            extractor=lambda r: r["data"]["listRecorders"]
        )
        return list(map(Recorder, result))

    def create_discussion(
        self,
        course_id: str,
        recorder: Recorder,
        topic: str = "From Hylable SDK",
        recordedAt: datetime.datetime = None,
        options: dict = {}
    ) -> Discussion:
        """
        ディスカッションを作成する関数

        作成したディスカッションに対する録音は :func:`~start_recording` メソッドで行う

        Args:
            course_id (str): ディスカッションを作成するコースのID
            recorder (Recorder): 録音に使うレコーダー
            topic (str): トピック
            recordedAt(datetime or None): 録音開始時刻。デフォルト(None)の場合は現在時刻
            options(dict): オプション設定

        Returns:
            Discussion: 作成したディスカッション

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> recorders = client.get_recorders()
            >>> discussion = client.create_discussion(courses[0].id, recorders[0])
        """

        # get course info
        course = self.get_course(course_id)

        if recordedAt is None:
            recordedAt = datetime.datetime.now().astimezone(datetime.timezone.utc).isoformat()
        variables = {"input": {
            "apikey": self.apikey,
            "cid": course_id,
            "oid": self.orgid,
            "recordedAt": recordedAt,
            "topic": topic,
            "recorder": {
                "id": recorder.id,
                "name": recorder.name
            },
            "options": course.flags,
        }}
        result = self.wrap_graphql(
            url=self.get_uri("discussion"),
            query=create_discussion,
            variables=variables
        )

        obj = {
            **json.loads(result["data"]["create"]["result"])[0],
            'cid': course_id,
            'oid': self.orgid,
            'recordedAt': recordedAt,
            'topic': topic,
        }
        return Discussion(obj)

    def start_recording(self, discussion: Discussion) -> None:
        """
        ディスカッションの録音を開始する関数

        :meth:`~create_discussion` で作成したディスカッションの録音を行う。
        録音に使用するレコーダーは引数に与えられた `discussion` オブジェクトの
        `recorder` プロパティで指定されている。

        Args:
            discussion (Discussion): 録音を行うディスカッションのオブジェクト

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> recorders = client.get_recorders()
            >>> discussion = client.create_discussion(courses[0].id, recorders[0])
            >>> client.start_recording(discussion)
        """
        variables = {
            "organizationId": self.orgid,
            "input": {
                "recorderId": discussion.recorder.id,
                "reqId": discussion.id,
                "dest": discussion.dest,
                "application": "discussion",
                "options": {
                    key: discussion.options[key]
                    for key in ["runAsr", "omitFullChannelAudio"]
                    if key in discussion.options
                },
            },
        }
        if discussion.options.get("runAsr"):
            variables["input"]["flexOptions"] = json.dumps({
                "organizationId": self.orgid,
                "courseId": discussion.course_id,
                "discussionId": discussion.id,
            })

        self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=recstart,
            variables=variables
        )

    def stop_recording(self, recorders: list[Recorder]):
        """
        レコーダーの録音を停止する関数

        録音中のレコーダーの録音を停止する関数。

        Args:
            recorders (list[Recorder]): リストで与えられたすべてのレコーダーの録音を停止できる。

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()
            >>> recorders = client.get_recorders()
            >>> discussion = client.create_discussion(courses[0].id, recorders[0])
            >>> client.start_recording(discussion)
            >>> time.sleep(10)
            >>> client.stop_recording(recorders[0])
        """
        variables = {
            "organizationId": self.orgid,
            "input": [r.id for r in recorders]
        }
        result = self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=recstop,
            variables=variables
        )
        return result

    def reboot_recorder(self, recorder: Recorder):
        """
        レコーダーを再起動する関数

        Args:
            recorder (Recorder): 再起動するレコーダー

        Examples:
            >>> client = HDClient()
            >>> recorders = client.get_recorders()
            >>> client.reboot_recorder(recorders[0])
        """
        variables = {
            "organizationId": self.orgid,
            "input": recorder.id
        }
        result = self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=reboot,
            variables=variables
        )
        return result

    def shutdown_recorder(self, recorder: Recorder):
        """
        レコーダーを再起動する関数

        Args:
            recorder (Recorder): 再起動するレコーダー

        Examples:
            >>> client = HDClient()
            >>> recorders = client.get_recorders()
            >>> client.shutdown_recorder(recorders[0])
        """
        variables = {
            "organizationId": self.orgid,
            "input": recorder.id
        }
        result = self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=shutdown,
            variables=variables
        )
        return result

    def speak_recorder(
            self, recorders: list[Recorder],
            content: str, language: str = "ja_JP") -> None:
        """
        レコーダーから音声合成を行う関数

        Args:
            recorder (Recorder): 音声合成を行うレコーダー
            content (str): 音声の内容
            language (str): 言語 (ja_JP or en_US)

        Examples:
            >>> client = HDClient()
            >>> recorders = client.get_recorders()
            >>> client.speak_recorder(recorders[0], "こんにちは")
        """
        variables = {
            "organizationId": self.orgid,
            "input": {
                "content": content,
                "language": language,
                "recorders": [r.id for r in recorders]
            }
        }
        result = self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=speak,
            variables=variables
        )
        return result

    def watch_discussion(
        self,
        callback: Callable[[Discussion], None] = lambda x: x
    ) -> None:
        """
        ディスカッションを監視する関数

        ディスカッションの作成や変更、削除検知すると、コールバック関数 callback が呼び出される。
        callback の引数は Discussion 型のオブジェクト。関数内で client.is_alive を False にすると監視を終了できる。

        Args:
            callback (Callable[[Discussion], None]): コールバック関数

        Examples:
            >>> client = HDClient()
            >>> def callback(discussion):
            >>>     print(discussion)
            >>> client.watch_discussion(callback)
        """

        def subcallback(discussion):
            return callback(Discussion(discussion))

        self.wrap_subscribe(
            f"{self.get_uri('discussion')}",
            queries=[subscribe_discussion_onchange, subscribe_discussion_ondelete],
            variables=[{"oid": self.orgid}, {"oid": self.orgid}],
            topic_filters=["onChangeDiscussionInOrg", "onDeleteDiscussionInOrg"],
            callback=subcallback
        )

    def watch_recorder(self, callback: Callable[[Recorder], None] = lambda x: x) -> None:
        """
        レコーダーの変更を監視する関数

        レコーダーの変更を監視する関数。組織に登録されているレコーダーの変更を検知すると、
        コールバック関数 callback が呼び出される。
        callback の引数は Recorder 型のオブジェクト。 関数内で client.is_alive を False にすると監視を終了できる。

        Args:
            course (Course): 監視するコース
            callback (Callable[[Discussion], None]): コールバック関数

        Examples:
            >>> client = HDClient()
            >>> def callback(recorder):
            >>>     print(recorder)
            >>> client.watch_recorder(callback)
        """
        def subcallback(recorder):
            return callback(Recorder(recorder))

        self.wrap_subscribe(
            f"{self.get_uri('recorder')}",
            queries=[subscribe_recorder_update],
            variables=[{'organizationId': self.orgid}],
            topic_filters=["onUpdateRecorder"],
            callback=subcallback,
        )

    def get_asr(self, discussion: Discussion) -> list[dict]:
        """
        音声認識結果を取得する関数

        Args:
            discussion (Discussion): 音声認識結果を得る Discussion ID

        Examples:
            >>> client = HDClient()
            >>> courses = client.get_courses()[0]
            >>> discussion = client.get_discussions(courses[0])[0]
            >>> client.get_asr(discussion)
        """

        # HS3Client で discusion に関するメタデータを取得
        hs3client = HS3Client(self.profile_name)
        metadata = hs3client.get_metadata(discussion.id)

        # 取得したメタデータにつて、次の条件にあるものをfilter する
        #  [1] 音声認識結果に対応するの ID に /result/ を含む
        #  [2] 音声認識結果の順番を表す name が数字
        asrs = [
            json.loads(m["value"]) for m in metadata
            if f"{discussion.id}/result/" in m["id"] and
               m["name"].isdigit()
        ]
        # 音声認識結果の発生開始順でソート
        asrs.sort(key=lambda m: m["startTime"])

        # actor index から、member を取得する
        asrs = [
            {
                **a,
                "member": None if "actor" not in a
                else discussion.members[a["actor"]["index"]]["member"],
            }
            for a in asrs]

        return asrs

    def get_available_discussion_reports(self) -> dict:
        """
        ダウンロード可能なレポートの一覧を取得する関数。 :func:`~get_discussion_report` で使用する。

        Returns:
            list[dict]: ダウンロード可能なレポートの一覧。各リストの要素は以下の通り。
                * name (str): レポートの名前
                * id (str): レポートのフォーマットID
                * lang (str): レポートの出力言語

        Examples:
            >>> client = HDClient()
            >>> reports = client.get_available_discussion_reports()
        """

        return self.available_reports["discussion"]

    def get_discussion_report(self, discussion: Discussion, report_format_id: str, lang: str = "ja") -> bytes:
        """
        ディスカッションの PDF レポートを取得する関数

        Args:
            discussion (Discussion): レポートを取得するディスカッションオブジェクト
            report_format_id (str): レポートのフォーマットID
            lang (str): レポートの出力言語

        Returns:
            bytes: PDF レポートのバイナリデータ

        Raises:
            ValueError: report_format_id が利用可能でないとき

        Examples:
            >>> client = HDClient()
            >>> course = client.get_courses()[0]
            >>> discussion = client.get_discussions(course.id)[0]
            >>> format = client.get_available_discussion_reports()[0]
            >>> report_content = client.get_discussion_report(discussion, format["id"], format["lang"])
            >>> pathlib.Path("report.pdf").write_bytes(report_content)
        """

        report_ids = [r["id"] for r in self.available_reports["discussion"]]
        if report_format_id not in report_ids:
            raise ValueError(f"report_format_id {report_format_id} is not available. " + \
                             f"Available report ids are: {report_ids}")

        url = self.get_uri('report')
        url += f"/course/{discussion.course_id}"
        url += f"/discussion/{discussion.id}"
        url += f"?filetype=url&reportformat={report_format_id}&reportlang={lang}"
        s3url = self.wrap_request("get", url, is_rawtext=True)
        return requests.get(s3url).content
