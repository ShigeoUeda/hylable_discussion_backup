from .common import BaseClient
from .queries_hs3 import list_metadata


class HS3Client(BaseClient):
    """
    HS3 (Hylable Sound Storage Service) との通信を行うクラス
    """
    def get_metadata(self, parent: str) -> list[dict]:
        """
        parent で指定した HS3 のメタデータを取得する関数

        Args:
            parent (str): 取得するメタデータの parent 要素

        Returns:
            list[dict]: 取得したメタデータのリスト

        Examples:
            >>> client = HS3Client()
            >>> metadatas = client.get_metadata("parent_id")
        """
        result = self.wrap_graphql_loop(
            url=self.get_uri("hs3"),
            query=list_metadata,
            variables={"filter": {"oid": self.orgid, "parent": parent}},
            extractor=lambda r: r["data"]["listMetadata"]
        )

        return result
