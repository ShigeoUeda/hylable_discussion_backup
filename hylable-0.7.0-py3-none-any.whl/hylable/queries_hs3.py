list_metadata = """
query ListMetadata(
    $filter: ItemFilterInput!
    $limit: Int
    $nextToken: String
) {
    listMetadata(filter: $filter, limit: $limit, nextToken: $nextToken) {
        items {
            oid
            id
            parent
            name
            type
            value
        }
        nextToken
    }
}
"""
