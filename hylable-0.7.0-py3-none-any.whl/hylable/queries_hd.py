get_discussions = """
query ListDiscussions($cid: ID!, $limit: Int, $nextToken: String) {
    listDiscussions(cid: $cid, limit: $limit, nextToken: $nextToken) {
        items {
            id
            cid
            oid
            recordedAt
            topic
            comment
            recorder {
                id
                name
                type
            }
            status
            progress
            duration
            group {
                name
                seats {
                    position
                    memberId
                }
            }
            annotations {
                id
                begin
                end
                label
                createdBy
                createdAt
                updatedBy
                updatedAt
            }
            statistics {
                numOfMembers
                sumTlotMs
                durationPerAzimuth {
                    azimuth
                    duration
                }
                activity
                overlap
                enhancement
                tlotMs
                dominantMs
                turntake
                pairwiseOverlap
            }
            postProcessingStatus {
                process
                status
            }
            application
            sourceType
        }
        nextToken
    }
}
"""

get_discussion = """
query GetDiscussion($did: ID!) {
    getDiscussion(id: $did){
        id
        cid
        oid
        recordedAt
        topic
        comment
        recorder {
            id
            name
            type
        }
        status
        progress
        duration
        group {
            name
            seats {
                position
                memberId
            }
        }
        framewiseAnalysis {
            activity
        }
        annotations {
            id
            begin
            end
            label
            createdBy
            createdAt
            updatedBy
            updatedAt
        }
        statistics {
            numOfMembers
            sumTlotMs
            durationPerAzimuth {
                azimuth
                duration
            }
            activity
            overlap
            enhancement
            tlotMs
            dominantMs
            turntake
            pairwiseOverlap
        }
        options {
            runAsr
        }
    }
}
"""

get_mp3 = """
query GetAudioUrl($apikey: ID!, $id: ID!) {
    getAudioUrl(apikey: $apikey, id: $id) {
        error
        result
    }
}
"""

get_recorders = """
query ListRecorders(
    $filter: TableRecorderFilterInput!
    $limit: Int
    $nextToken: String
) {
    listRecorders(filter: $filter, limit: $limit, nextToken: $nextToken) {
        items {
            id
            assign
            connected
            name
            organizationId
            status
            version
            type
        }
        nextToken
    }
}
"""

create_discussion = """
mutation Create($input: [CreateInput]) {
    create(input: $input) {
        error
        result
    }
}
"""

update_discussion = """
mutation Update($input: DiscussionInput!) {
    update(input: $input) {
        error
        result
    }
}
"""


recstart = """
mutation RecStart($organizationId: ID!, $input: [RecStartInput]!) {
    recStart(organizationId: $organizationId, input: $input) {
        error
        result
    }
}
"""

recstop = """
mutation RecStop($organizationId: ID!, $input: [ID]!) {
    recStop(organizationId: $organizationId, input: $input) {
        error
        result
    }
}
"""

reboot = """
mutation Reboot($organizationId: ID!, $input: [ID]!) {
    reboot(organizationId: $organizationId, input: $input) {
        error
        result
    }
}
"""

shutdown = """
mutation Shutdown($organizationId: ID!, $input: [ID]!) {
    shutdown(organizationId: $organizationId, input: $input) {
        error
        result
    }
}
"""

speak = """
mutation Speak($organizationId: ID!, $input: SpeakInput!) {
    speak(organizationId: $organizationId, input: $input) {
        error
        result
    }
}
"""

del_discussion = """
mutation Del($input: [ID!]) {
    del(input: $input) {
        error
        result
    }
}
"""

subscribe_discussion_ondelete = """
subscription OnDeleteDiscussionInOrg($oid: ID!) {
    onDeleteDiscussionInOrg(oid: $oid) {
        id
        cid
        oid
        recordedAt
        topic
        comment
        recorder {
            id
            name
            type
        }
        status
        progress
        duration
        group {
            name
            seats {
                position
                memberId
            }
        }
        framewiseAnalysis {
            activity
        }
        statistics {
            numOfMembers
            sumTlotMs
            durationPerAzimuth {
                azimuth
                duration
            }
            activity
            overlap
            enhancement
            tlotMs
            dominantMs
            turntake
            pairwiseOverlap
        }
    }
}
"""

subscribe_discussion_onchange = """
subscription OnChangeDiscussionInOrg($oid: ID!) {
    onChangeDiscussionInOrg(oid: $oid) {
        id
        cid
        oid
        recordedAt
        topic
        comment
        recorder {
            id
            name
            type
        }
        status
        progress
        duration
        group {
            name
            seats {
                position
                memberId
            }
        }
        annotations {
            id
            begin
            end
            label
            createdBy
            createdAt
            updatedBy
            updatedAt
        }
    }
}
"""

subscribe_recorder_update = """
subscription OnUpdateRecorder($organizationId: ID!) {
    onUpdateRecorder(organizationId: $organizationId) {
        id
        name
        organizationId
        type
        assign
        connected
        status
        version
    }
}
"""
