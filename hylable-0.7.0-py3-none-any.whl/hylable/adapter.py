"""
Hylable Adapter を操作するソフトウェアを開発するためのモジュールです。
最初に :class:`AdapterClient` クラスのインスタンスを作成して、そのメソッドを実行することで操作を行います。

"""
import datetime
import json
import pathlib
import re

import requests
from .common import BaseClient
from .queries_adapter import create_session, analyze_session


class AdapterClient(BaseClient):
    """
    Hylable Adapter との通信を行うクラス
    """

    def upload_zoom_folder(
        self,
        folder: pathlib.Path,
        course_id: str,
        topic: str = "From Hylable SDK",
        recordedAt: datetime.datetime = None,
    ) -> None:
        """
        Zoom で参加者ごとの音声を個別保存された録画フォルダを Adapter にアップロードする関数

        Args:
            folder (pathlib.Path): Zoom 録画フォルダ
            course_id (str): :class:`~hylable.hd.Course` のID
            topic (str): トピック
            recordedAt(datetime or None): 録音開始時刻。デフォルト (`None`)の場合は現在時刻

        """
        # 関連ファイルのリストアップ
        file_list = []
        for filename in folder.glob("**/*"):
            if filename.suffix == ".m4a":
                file_list.append(filename)

        assert len(file_list) > 0, "Failed to find Zoom audio files"

        # フォーマットの判定
        format = None
        if "audio_only" in file_list[0].stem:
            format = "FORMAT_57"
        elif "audio" in file_list[0].stem:
            format = "FORMAT_LATEST"
        else:
            raise ValueError("Failed to find Zoom audio files")

        # メンバーのリストアップ
        member_files = list(sorted([f for f in file_list if "Audio Record" in str(f)]))
        if format == "FORMAT_57":
            pattern = r"audio_only_[0-9]+_(.*)\.m4a"
        elif format == "FORMAT_LATEST":
            pattern = r"audio(.*)[0-9]{11}\.m4a"
        member_names = [re.findall(pattern, f.name)[0] for f in member_files]

        # メンバーオブジェクトの作成
        member_objs = []
        for i, m in enumerate(member_names):
            if member_names.count(m) > 1:
                member_names[i] += f" {member_names.count(m)-1}"
            member_objs.append({"id": member_names[i], "name": member_names[i]})

        self._upload_file(
            course_id=course_id,
            topic=topic,
            recordedAt=recordedAt,
            file_list=file_list,
            members=member_objs,
            type="",
        )

    def upload_media_file(
        self,
        mediafile: pathlib.Path,
        nmembers: int,
        course_id: str,
        topic: str = "From Hylable SDK",
        recordedAt: datetime.datetime = None,
    ) -> None:
        """
        音声ファイルを Adapter にアップロードする関数

        Args:
            mediafile (pathlib.Path): 分析したい音声ファイル
            nmembers (int): ファイルに含まれるメンバー数。自動推定の場合は `None` を与える。
            course_id (str): :class:`~hylable.hd.Course` のID
            topic (str): トピック
            recordedAt(datetime or None): 録音開始時刻。デフォルト(`None`)の場合は現在時刻
        """
        assert mediafile.exists(), "mediafile does not exist"
        assert not mediafile.is_dir(), "mediafile must not be a directory"
        assert mediafile.is_file(), "mediafile must be a file"

        if nmembers is None:
            members = None
        else:
            members = [
                {"id": f"Speaker {i+1}", "name": f"Speaker {i+1}"}
                for i in range(nmembers)
            ]
        self._upload_file(
            course_id=course_id,
            topic=topic,
            recordedAt=recordedAt,
            file_list=[mediafile],
            type="onech",
            members=members,
            is_flatten=True
        )

    def _upload_file(
        self,
        file_list: list,
        course_id: str,
        topic: str = "From Hylable SDK",
        recordedAt: datetime.datetime = None,
        type: str = None,
        members: list = None,
        is_flatten=False
    ) -> str:

        if recordedAt is None:
            recordedAt = datetime.datetime.now().astimezone(datetime.timezone.utc).isoformat()

        file_pair_dict = {
            f"{index}_{f.name}" if is_flatten else str(f): f
            for index, f in enumerate(file_list)
        }

        variables = {"input": {
            "oid": self.orgid,
            "cid": course_id,
            "recordedAt": recordedAt,
            "topic": topic,
            "inputFiles": list(file_pair_dict.keys()),
            "members": members,
            "type": type
        }}
        result = self.wrap_graphql(
            url=self.get_uri("adapter"),
            query=create_session,
            variables=variables
        )
        result = json.loads(result["data"]["create"]["result"])

        for filename, url in result["inputUrls"].items():
            with open(file_pair_dict[filename], "rb") as f:
                requests.put(
                    url,
                    data=f,
                    headers={"Content-Type": "application/octet-stream"}
                )
        self.wrap_graphql(
            url=self.get_uri("adapter"),
            query=analyze_session,
            variables={
                "oid": self.orgid,
                "id": result["session"]["id"],
            }
        )
        return result["session"]
