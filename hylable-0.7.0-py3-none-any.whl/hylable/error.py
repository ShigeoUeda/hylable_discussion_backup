class DataNotFoundError(Exception):
    """データが無いことを表す"""
    pass


class AuthenticationError(Exception):
    """認証に失敗したことを表す"""
    pass


class InternalServerError(Exception):
    """サーバーエラーがあったことを表す"""
    pass
