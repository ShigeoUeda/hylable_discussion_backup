create_session = """
mutation Create($input: CreateInput) {
    create(input: $input) {
        error
        result
    }
}
"""

analyze_session = """
mutation Analyze($oid: ID!, $id: ID!) {
    analyze(oid: $oid, id: $id) {
        error
        result
    }
}
"""