"""
Bamiel を操作するソフトウェアを開発するためのモジュールです。
最初に :class:`BamielClient` クラスのインスタンスを作成して、そのメソッドを実行することで操作を行います。

データは、以下の `dataclass` で定義されるクラスのオブジェクトとして扱います

- フィールド: :class:`Field`
- ヒートマップ: :class:`Heatmap`
- オブジェクト: :class:`FieldObject`

"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from dateutil.parser import parse as dparse

import numpy

from .common import BaseClient, BaseDataModel
from .error import DataNotFoundError
from .hd import Recorder
from .queries_hd import get_recorders, recstart, recstop


@dataclass
class Field(BaseDataModel):
    """フィールドを表す `dataclass`

    Attributes:
        id (str):
            `fld_` から始まるフィールドのID
        orgid (str):
            `org_` から始まる組織のID
        name (str):
            フィールドの名前
        created_at (datetime):
            フィールドが作成された時刻
        current (bool):
            このフィールド定義が最新のものであれば True、過去のものなら False になる
        image (str):
            フィールドへのパス
        size (dict):
            `{"w": W, "h": H}` の形式で表されるフィールドのサイズ
    """
    id: str = ''
    name: str = ''
    created_at: datetime = None
    areas: list = field(default_factory=list)
    current: bool = False
    image: str = ''
    orgid: str = ''
    size: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        keypairs = [
            ('id', 'id'),
            ('name', 'name'),
            ('created_at', 'created_at'),
            ('areas', 'areas'),
            ('current', 'current'),
            ('image', 'image'),
            ('orgid', 'oid'),
            ('size', 'size'),
        ]
        self._parse_rawdata(keypairs)

        if self.created_at is not None:
            self.created_at = dparse(self.created_at)

        if self.size:
            assert 'w' in self.size
            assert 'h' in self.size

    def _get_data(self, client):
        return client.get_field(self.id)


@dataclass
class Heatmap(BaseDataModel):
    """
    フィールドのヒートマップを表す `dataclass`

    Attributes:
        id (str):
            ヒートマップが所属するフィールドの ID
        orgid (str):
            `org_` から始まる組織の ID
        timestamp (datetime):
            このヒートマップが対応する時刻
        window (float):
            このヒートマップの計算に使われた計算窓の長さ
        heatmap (numpy.array):
            2次元配列で表現されるヒートマップ
        recorder_ids (list[str]):
            このヒートマップの計算に使われたレコーダー ID のリスト
        min (float):
            ヒートマップの最小値
        max (float):
            ヒートマップの最大値
        average (float):
            ヒートマップの平均値
        field_size (dict):
            `{"w": W, "h": H}` の形式で表されるフィールドのサイズ
        updated_at (datetime):
            このヒートマップが計算された時刻
    """
    id: str = ''  # Field ID
    orgid: str = ''
    timestamp: datetime = None
    window: float = 0
    heatmap: numpy.array = field(default_factory=lambda: numpy.array([]))
    recorder_ids: list[str] = field(default_factory=list)
    min: float = 0
    max: float = 0
    average: float = 0
    field_size: dict = field(default_factory=dict)
    updated_at: datetime = None

    def __post_init__(self) -> None:
        self.id = self.rawdata['id']
        self.orgid = self.rawdata['oid']
        self.timestamp = dparse(self.rawdata['timestamp'])
        self.window = self.rawdata['window']
        self.heatmap = numpy.array(self.rawdata['heatmap'], dtype=numpy.float32)
        self.recorder_ids = self.rawdata['recorders']
        self.min = self.rawdata['min']
        self.max = self.rawdata['max']
        self.average = self.rawdata['average']
        self.field_size = {
            'w': self.rawdata['field_size']['w'],
            'h': self.rawdata['field_size']['h'],
        }
        self.updated_at = self.rawdata['updated_at']
        if self.updated_at is not None:
            self.updated_at = dparse(self.updated_at)

    def _get_data(self, client):
        fieldobj = Field({'id': self.id})
        return client.get_heatmap(fieldobj, self.timestamp)


@dataclass
class FieldObject(BaseDataModel):
    """
    フィールド上のオブジェクトを表す `dataclass`
    たとえば、人の位置やモノの位置などが上げられる。

    Attributes:
        id (str):
            オブジェクトのID
        orgid (str):
            `org_` から始まる組織のID
        type (str):
            任意に指定できるオブジェクトの種類
        name (str):
            任意に指定できるオブジェクトの名前
    """
    id: str = ''
    orgid: str = ''
    type: str = ''
    name: str = ''

    def __post_init__(self):
        # 列挙したキーについて、もし初期値でなければすでにある値を使う。
        # 初期値の場合は、rawdata から値を取り出す。
        keypairs = [
            ('id', 'id'),
            ('orgid', 'oid'),
            ('type', 'type'),
            ('name', 'name')
        ]
        self._parse_rawdata(keypairs)

    def _get_data(self, client):
        return client.get_object(self.id)

    def _as_dict(self) -> dict:
        return {
            "id": self.id,
            "oid": self.orgid,
            "type": self.type,
            "name": self.name,
        }


@dataclass
class FieldObjectPosition(BaseDataModel):
    """
    フィールド上のオブジェクトの位置を表す `dataclass`
    :class:`~FieldObjectSnapshot` のメンバーとして使われる。

    Attributes:
        id (str):
            このポジションが関連するオブジェクトのID
        orgid (str):
            `org_` から始まる組織のID
        field_id (str):
            このオブジェクトがいたフィールドの ID
        timestamp (datetime):
            オブジェクトがこの位置にいた時刻
        position (dict):
            `{"x": X, "y": Y}` の形式で表現んされるオブジェクトの位置

    """
    id: str = ''
    orgid: str = ''
    field_id: str = ''
    timestamp: datetime = None
    position: dict = field(default_factory=dict)

    def __post_init__(self):
        keypairs = [
            ('id', 'id'),
            ('orgid', 'oid'),
            ('field_id', 'field_id'),
            ('timestamp', 'timestamp'),
            ('position', 'position'),
        ]
        self._parse_rawdata(keypairs)

    def _as_dict(self) -> dict:
        return {
            'id': self.id,
            'oid': self.orgid,
            'field_id': self.field_id,
            'timestamp': date2str(self.timestamp),
            'position': self.position,
        }


@dataclass
class FieldObjectSnapshot(BaseDataModel):
    """
    ある時間の範囲中にフィールドに含まれるのオブジェクトとその
    位置をあらわす `dataclass`

    Attributes:
        orgid (str):
            `org_` から始まる組織の ID
        start (datetime):
            このスナップショットが対象とする時間範囲の開始時刻
        end (datetime):
            このスナップショットが対象とする時間範囲の終了時刻。
            `end` か `range_sec` の片方のみ設定でき、もう一方は自動で計算される
        range_sec (int):
            このスナップショットが対象とする時間範囲の長さ(単位: 秒)。
            `end` か `range_sec` の片方のみ設定でき、もう一方は自動で計算される
        positions (list[FieldObjectPosition]):
            このスナップショットの対象範囲のオブジェクトの位置のリスト
    """
    orgid: str = ''
    start: datetime = None
    end: datetime = None
    range_sec: int = None
    positions: list[FieldObjectPosition] = field(default_factory=list)

    def __post_init__(self):
        if self.end is not None and self.range_sec is not None:
            raise ValueError("end and range_sec cannot be given simultaneously.")
        if self.end is None:
            self.end = self.start + timedelta(seconds=self.range_sec)
        if self.range_sec is None:
            self.range_sec = (self.end - self.start).total_seconds()

        for p in self.positions:
            p.orgid = self.orgid

    def get_positions(self) -> list[dict]:
        return [p._as_dict() for p in self.positions]

    def set_orgid(self, orgid: str) -> None:
        self.orgid = orgid
        for p in self.positions:
            p.orgid = self.orgid


def date2str(dateobj):
    return dateobj.isoformat(timespec="microseconds").replace("+00:00", "Z")


class BamielClient(BaseClient):
    """
    Bamiel との通信を行うクラス
    """
    def get_fields(self) -> list[Field]:
        """
        すべてのフィールドの情報を得る関数

        Returns:
            list[Field]: フィールドのリスト

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
        """
        url = f'{self.get_uri("bamiel")}/definition?oid={self.orgid}'
        return list(map(Field, self.wrap_request('get', url)))

    def get_field(self, field_id: str) -> Field:
        """
        特定のフィールドの詳細を得る関数

        Args:
            field_id(str): フィールドのID

        Returns:
            Field: ID に対応するフィールドのオブジェクト

        Raises:
            DataNotFoundError: 指定されたフィールドIDがない時

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> field = client.get_field(fields[0].id)
        """
        url = f'{self.get_uri("bamiel")}/definition/{field_id}'
        try:
            return Field(self.wrap_request('get', url))
        except Exception:
            raise DataNotFoundError(f"Field ID {field_id} not found")

    def get_heatmap(self, field: Field, timestamp: datetime = datetime.now(timezone.utc)) -> Heatmap:
        """
        指定されたフィールドと時刻のヒートマップを得る関数

        Args:
            field (Field): ヒートマップを取得するフィールド
            timestamp (datetime): ヒートマップを取得する時刻。与えられない場合は現在時刻

        Returns:
            Heatmap: 指定されたフィールド・時刻のヒートマップ

        Raises:
            DataNotFoundError: ヒートマップがないとき

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> heatmap = client.get_heatmap(fields[0]).heatmap
        """
        url = f'{self.get_uri("bamiel")}/analysis/{field.id}/latest?timestamp={date2str(timestamp)}'
        try:
            return Heatmap(self.wrap_request('get', url))
        except Exception:
            raise DataNotFoundError(
                f"Heatmap of Field ID {field.id} at {date2str(timestamp)} not found"
            )

    def get_objects(self) -> list[FieldObject]:
        """
        すべてのオブジェクトの情報を得る関数

        Returns:
            list[FieldObject]: オブジェクトのリスト

        Examples:
            >>> client = BamielClient()
            >>> objects = client.get_objects()
        """
        url = f'{self.get_uri("bamiel")}/object/metadata'
        return list(map(FieldObject, self.wrap_request('get', url)))

    def get_object(self, object_id: str) -> FieldObject:
        """
        指定された ID のオブジェクトを得る関数

        Args:
            object_id (str): オブジェクトのID

        Returns:
            FieldObject: 指定されたオブジェクト

        Raises:
            DataNotFoundError: オブジェクトがないとき

        Examples:
            >>> client = BamielClient()
            >>> objs = client.get_objects()
            >>> obj = client.get_object(objs[0])
        """
        url = f'{self.get_uri("bamiel")}/object/metadata'
        found = list(map(FieldObject, self.wrap_request('get', url, params={
            'object_id': object_id
        })))
        if len(found) == 1:
            return found[0]
        else:
            raise DataNotFoundError(f"Object {object_id} not found")

    def add_objects(self, objects: list[FieldObject]) -> list[FieldObject]:
        """
        オブジェクトを追加する関数

        Args:
            objects (list[FieldObject]): 追加したいオブジェクトのリスト

        Returns:
            list[FieldObject]: 追加されたオブジェクト

        Examples:
            >>> client = BamielClient()
            >>> objs = [
                    FieldObject(id='obj1', type='human', name='Tom'),
                    FieldObject(id='obj2', type='human', name='Alice'),
                ]
            >>> obj = client.add_object(objs)
        """
        url = f'{self.get_uri("bamiel")}/object/metadata'
        for o in objects:
            o.orgid = self.orgid

        return [
            FieldObject(self.wrap_request('post', f'{url}', data=o._as_dict()))
            for o in objects
        ]

    def del_object(self, object_id: str):
        """
        オブジェクトを削除する関数

        Args:
            object_id (str): 削除したいオブジェクトのID

        Examples:
            >>> client = BamielClient()
            >>> client.del_object('obj1')
        """
        url = f'{self.get_uri("bamiel")}/object/metadata/{object_id}'
        self.wrap_request('delete', url)

    def _get_snapshot(self, query, start, end, range_sec):
        if end is not None and range_sec is not None:
            raise ValueError("end and range_sec cannot be given simultaneously.")
        if end is None:
            end = start + timedelta(seconds=range_sec)
        if range_sec is None:
            range_sec = (end - start).total_seconds()

        url = f'{self.get_uri("bamiel")}/object/position'
        positions = self.wrap_request('get', url, params={
            **query,
            "start": date2str(start),
            "range": range_sec
        })
        return FieldObjectSnapshot(
            orgid=self.orgid,
            start=start,
            end=end,
            positions=list(map(FieldObjectPosition, positions))
        )

    def get_snapshot_by_field(
            self, field: Field,
            start: datetime,
            end: datetime = None,
            range_sec: int = None
    ) -> FieldObjectSnapshot:
        """
        指定されたフィールドの指定された時間帯における、
        オブジェクトの位置情報を得る関数

        Args:
            field (Field): データを取得するフィールド
            start (datetime): データを取得する開始時刻
            end (datetime): データを取得する終了時刻。`end` または `range_sec` の片方の指定が必要
            range_sec (int): データを取得する時間間隔 (単位は秒)

        Returns:
            FieldObjectSnapshot: オブジェクトの位置を表す

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> start = datetime.datetime(2023, 1, 1, 0, 0, 0, 0)
            >>> range_sec = 120
            >>> snapshot = client.get_snapshot_by_field(
                    fields[0], start, range_sec=range_sec
                )
        """
        return self._get_snapshot({"fid": field.id}, start, end, range_sec)

    def get_snapshot_by_object(
            self, fieldObject: FieldObject,
            start: datetime,
            end: datetime = None,
            range_sec: int = None
    ) -> FieldObjectSnapshot:
        """
        指定されたオブジェクトの指定された時間帯における位置情報を得る関数

        Args:
            fieldObject (FieldObject): データを取得したいオブジェクト
            start (datetime): データを取得する開始時刻
            end (datetime): データを取得する終了時刻。`end` または `range_sec` の片方の指定が必要
            range_sec (int): データを取得する時間間隔 (単位は秒)

        Returns:
            FieldObjectSnapshot: オブジェクトの位置を表す

        Examples:
            >>> client = BamielClient()
            >>> objs = client.get_objects()
            >>> start = datetime.datetime(2023, 1, 1, 0, 0, 0, 0)
            >>> range_sec = 120
            >>> snapshot = client.get_snapshot_by_object(
                    objs[0], start, range_sec=range_sec
                )
        """
        return self._get_snapshot({"object_id": fieldObject.id}, start, end, range_sec)

    def add_snapshot(self, snapshot: FieldObjectSnapshot) -> None:
        """
        指定されたオブジェクト位置を表すスナップショットを追加する関数

        Args:
            snapshot (FieldObjectSnapshot): 追加したいフィールドのスナップショット

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> time1 = datetime.datetime(2023, 1, 1, 0, 0, 0, 0)
            >>> time2 = datetime.datetime(2023, 1, 1, 0, 0, 5, 0)
            >>> snapshot = FieldObjectSnapshot(
                    start=time1,
                    range_sec=70,
                    positions=[
                        FieldObjectPosition({
                            "id": "obj1",
                            "field_id": field[0].id,
                            "timestamp": time1,
                            "position": {"x": 20, "y": 20}
                        },
                        FieldObjectPosition({
                            "id": "obj1",
                            "field_id": field[0].id,
                            "timestamp": time2,
                            "position": {"x": 21, "y": 21}
                        })
                    ]
                )
            >>> client.add_snapshot(snapshot)
        """
        url = f'{self.get_uri("bamiel")}/object/position'
        snapshot.set_orgid(self.orgid)
        self.wrap_request('post', url, data=snapshot.get_positions())

    def del_snapshot(self, snapshot: FieldObjectSnapshot) -> None:
        """
        指定されたオブジェクト位置を表すスナップショットを削除する関数

        Args:
            snapshot (FieldObjectSnapshot): 削除したいフィールドのスナップショット

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> time1 = datetime.datetime(2023, 1, 1, 0, 0, 0, 0)
            >>> time2 = datetime.datetime(2023, 1, 1, 0, 0, 5, 0)
            >>> snapshot = FieldObjectSnapshot(
                    start=time1,
                    range_sec=70,
                    positions=[
                        FieldObjectPosition({
                            "id": "obj1",
                            "field_id": field[0].id,
                            "timestamp": time1,
                            "position": {"x": 20, "y": 20}
                        },
                        FieldObjectPosition({
                            "id": "obj1",
                            "field_id": field[0].id,
                            "timestamp": time2,
                            "position": {"x": 21, "y": 21}
                        })
                    ]
                )
            >>> client.del_snapshot(snapshot)
        """
        for pos in snapshot.positions:
            self.del_position(pos)

    def del_position(self, position: FieldObjectPosition) -> None:
        """
        指定されたオブジェクト位置を削除する関数

        Args:
            position (FieldObjectPosition): 削除したいオブジェクト位置

        Examples:
            >>> client = BamielClient()
            >>> pos = FieldObjectPosition({
                    "id": "obj1",
                    "field_id": field[0].id,
                    "timestamp": time1,
                    "position": {"x": 20, "y": 20}
                })
            >>> client.del_position(pos)
        """
        baseurl = f'{self.get_uri("bamiel")}/object/position'
        self.wrap_request(
            'delete',
            f"{baseurl}/%(id)s/%(timestamp)s" % position._as_dict()
        )

    def get_assigned_recorders(self, field: Field) -> list[Recorder]:
        """
        与えられたフィールドに登録されているレコーダーの一覧を取得する関数

        Args:
            field (Field): レコーダーの一覧を取得したいフィールド

        Returns:
            List[Recorder]: レコーダーの一覧

        Examples:
            >>> client = BamielClient()
            >>> recorders = client.get_assigned_recorders()
        """
        result = self.wrap_graphql_loop(
            url=self.get_uri("recorder"),
            query=get_recorders,
            variables={"filter": {"organizationId": {"eq": self.orgid}, "assign": {"eq": field.id}}},
            extractor=lambda r: r["data"]["listRecorders"]
        )
        # 取得したレコーダーを後処理する
        # 1. レコーダー名でソート
        # 2. Recorderクラスに変換
        return list(map(Recorder, sorted(result, key=lambda r: r["name"])))

    def start(self, field: Field) -> None:
        """
        指定されたフィールドの分析を開始する関数

        Args:
            field (Field): 分析を開始したいフィールドのID

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> client.start(fields[0])
        """

        variables = {
            "organizationId": self.orgid,
            "input": [
                {
                    "recorderId": r.id,
                    "application": "field",
                    "keepRecording": True,
                    "options": {
                        "omitFullChannelAudio": True,
                    }
                }
                for r in self.get_assigned_recorders(field)
            ]
        }
        self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=recstart,
            variables=variables
        )

    def stop(self, field: Field) -> None:
        """
        指定されたフィールドの分析を停止する関数

        Args:
            field (Field): 分析を停止したいフィールドのID

        Examples:
            >>> client = BamielClient()
            >>> fields = client.get_fields()
            >>> client.stop(fields[0])
        """
        variables = {
            "organizationId": self.orgid,
            "input": [
                r.id
                for r in self.get_assigned_recorders(field)
            ]
        }
        self.wrap_graphql(
            url=self.get_uri("recorder"),
            query=recstop,
            variables=variables
        )
